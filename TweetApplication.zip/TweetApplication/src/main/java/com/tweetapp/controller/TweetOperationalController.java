package com.tweetapp.controller;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.tweetapp.model.userTweets;
import com.tweetapp.service.TweetService;

public class TweetOperationalController {

	
	TweetService tweetService=new TweetService();
	
	public boolean nameValidator(String name)
	{
		 String regx = "^[\\p{L} .'-]+$";
		    Pattern pattern = Pattern.compile(regx,Pattern.CASE_INSENSITIVE);
		    Matcher matcher = pattern.matcher(name);
		  return matcher.find();
	}
	public boolean genderValidator(String name)
	{
		return (name.equalsIgnoreCase("M")|| name.equalsIgnoreCase("F") || name.equalsIgnoreCase("NB"))?true:false;
			
	}
	public boolean emailValidator(String email)
	{
		 String regx = "^[A-Za-z0-9+_.-]+@(.+){3}$";
		    Pattern pattern = Pattern.compile(regx);
		    Matcher matcher = pattern.matcher(email);
		  return matcher.find();
	}
	public boolean passwordValidator(String password)
	{
		 String regx ="^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#&()�[{}]:;',?/*~$^+=<>]).{8,20}$";
		    Pattern pattern = Pattern.compile(regx);
		    Matcher matcher = pattern.matcher(password);
		  return matcher.find();
	}

	public List<userTweets> getAllTweets()
	{
		return this.tweetService.getAllTweets();
	}
	public List<userTweets> getAllMyTweets(String email)
	{
		return this.tweetService.getAllMyTweets(email);
	}
	public boolean postTweet(userTweets tweet)
	{
		if(this.tweetService.registerTweet(tweet)==1)
		{
			return true;
		}
		return false;
			
	}
}
