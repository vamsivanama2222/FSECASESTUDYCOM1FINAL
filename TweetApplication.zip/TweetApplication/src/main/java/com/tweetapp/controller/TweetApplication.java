package com.tweetapp.controller;

import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.tweetapp.model.Users;
import com.tweetapp.model.userTweets;
import com.tweetapp.util.TewwtAppTableFormatter;
import com.tweetapp.util.TweetAppEncryption;
import com.tweetapp.util.TweetAppValidation;

public class TweetApplication {
	public static Scanner sc=new Scanner(System.in);
	public static TweetLoginController tweetLoginController=new TweetLoginController();
	public static TweetOperationalController operationalController=new TweetOperationalController(); 
	public static TweetAppEncryption encryption=new TweetAppEncryption();
	public static TweetAppValidation appValidater;
	public static TewwtAppTableFormatter formatter;
	public static void LoginModule()
	{
		
		System.out.println("***Welcome to TweetApplication***");
		System.out.println("Do you want to register or login?");
		System.out.println("1.Login");
		System.out.println("2.Register");
		System.out.println("3.Forgot Password");
		int choice=sc.nextInt();
		sc.nextLine();
		switch (choice) {
		case 1:  
			    Users user=login_user();
			    if(user!=null)
			    	OperationalModule(user);
			    break;
		case 2:
			    boolean res_register=register_user();
			    if(res_register==true)
			    {
			    	
			    	System.out.println("Register Success please login...");
			    	
			    }
			    else
			    {
			    	System.out.println("Some Error while handling register...");
			    	register_user();
			    }
			    break;	
		case 3:
		    String resetPassword=resetPassword();
		    System.out.println(resetPassword);	 
		    break;
		default:
			System.out.println("Please select a number within the given choices");
			break;
		}
		
	}
	private static String resetPassword()
	{
		System.out.println("Please Enter UserName");
		 String  email =(String)TweetAppValidation.validationChecker("email");
		 System.out.println("Enter new Password");
		 String passwordWithoutEncryption =(String)TweetAppValidation.validationChecker("password");
			
		String password= encryption.encrypt(passwordWithoutEncryption, "secretKey");
		return  tweetLoginController.resetStatus(password, email);
	}
	private static boolean register_user() {
		
		
		String password;
		
		System.out.println("Please fill the required details for registration");
		System.out.println("Enter Firstname");
		String firstname = (String)TweetAppValidation.validationChecker("name");
		
		System.out.println("Enter Lastname");
		String lastname =	(String)TweetAppValidation.validationChecker("name");
	
		System.out.println("Enter your Gender [M/F/NB]");
		String  gender =(String)TweetAppValidation.validationChecker("gender");
		
		System.out.println("Enter your Date-Of-Birth [dd/MM/yyyy]");
		java.sql.Date userDob=null;
		  Date date=(Date)TweetAppValidation.validationChecker("date");
		  userDob=new java.sql.Date(date.getTime());
			
		System.out.println("Enter your Email");
		 String  email =(String)TweetAppValidation.validationChecker("email");
		 
		System.out.println("Enter Password");
		String passwordWithoutEncryption =(String)TweetAppValidation.validationChecker("password");
		
		password= encryption.encrypt(passwordWithoutEncryption, "secretKey");
		 Users newUser=new Users(firstname,lastname,gender,userDob,email,password);
		return  tweetLoginController.registerUser(newUser);
	}
	
	private static Users login_user() {
		System.out.println("Please Enter Login Id");
		 String  username =(String)TweetAppValidation.validationChecker("email");
		System.out.println("Please Enter Password");
		String password =(String)TweetAppValidation.validationChecker("userPassword");
		Users user=tweetLoginController.isUserExist(username, password);
		if(user!=null) {
			System.out.println("Hello! "+user.getFirstName());
			
		}
		else
			System.out.println("Login Failed. Incorrect User name or Password");
		return user;
	}
	public static void OperationalModule(Users user)
	{
		try {
		
		System.out.println("Select a operation to proceed");
		System.out.println("1.Post a tweet");
		System.out.println("2.View All tweets");
		System.out.println("3.View My tweets");
		System.out.println("4.View all Users");
		System.out.println("5.Reset password/UpdatePassword");
		System.out.println("6.Logout");
		int ch=sc.nextInt();
		switch (ch) {
		case 1:
			sc.nextLine();
			System.out.println("Enter your Tweet Msg ");
			String msg= sc.nextLine();
		
			boolean res_Tweet=operationalController.postTweet(new userTweets(user.getFirstName(),user.getEmail(),msg));
			if(res_Tweet==true)
				System.out.println("Posted Tweet SuccessFully!...");
			else
				System.out.println("Sorry Something Went Wrong:)");
			OperationalModule(user);
			break;
		case 2:
			System.out.println("Here is All the userTweets");
			List<userTweets> allTweets=operationalController.getAllTweets();
			formatter=new TewwtAppTableFormatter(3,"NAME","EMAIL","TWEET MESSAGES");
			allTweets.forEach(element->formatter.addRow(element.getUserName(),element.getUserEmail(),element.getTweetMsg()));
			formatter.print();
			OperationalModule(user);
			break;
		case 3:
			System.out.println("Here is All My Tweets");
			List<userTweets> allMyTweets=operationalController.getAllMyTweets(user.getEmail());
			formatter=new TewwtAppTableFormatter(2,"NAME","TWEET MESSAGES");
			allMyTweets.forEach(element->formatter.addRow(element.getUserName(),element.getTweetMsg()));
			formatter.print();
			OperationalModule(user);
			break;
		case 4:
			System.out.println("Here is TweetApplicationUsers.....!");
			List<Users> allUsers=tweetLoginController.getAllUsers();
			formatter=new TewwtAppTableFormatter(5, "FIRSTNAME", "LASTNAME", "GENDER" ,"DATE-OF-BIRTH", "EMAIL");
			allUsers.forEach(element->formatter.addRow(element.getFirstName(),
					  element.getLastName(), element.getGender(),element.getDob().toString(), element.getEmail()));
			formatter.print();
			OperationalModule(user);
			break;
		case 5:
			System.out.println("Update Password is open for U ...!");
			String newPassWithoutEncrption =(String)TweetAppValidation.validationChecker("password");
			String newPass= encryption.encrypt(newPassWithoutEncrption, "secretKey");
			boolean res=tweetLoginController.updateUserPassword(newPass, user.getEmail());
			if(res==true)
			{
				System.out.println("Hurrayy----!..password updates Successfullyy....:)");
				
			}
			else
			{
				System.out.println("Some thing went wrong please try again later...");
			}
			OperationalModule(user);
			break;
		case 6:
			System.out.println("Thank you for using Tweet Application...!");
			break;
		default:
			System.out.println("Please select a number within the given choices");
			OperationalModule(user);
			break;
		}
	}
	catch ( InputMismatchException ime)
	{
		System.out.println("Incorrect input, Please Enter a valid input.");
		
		sc.nextLine();
		OperationalModule(user);
	}
	}
	public static void main(String[] args) {
		
		while(true) {
		try {
			
				LoginModule();
			}
			catch ( InputMismatchException ime)
			{
				System.out.println("Incorrect input, Please Enter a valid input.");
				
					sc.nextLine();
				
			}
			
		}
		
	
		
	}

}
